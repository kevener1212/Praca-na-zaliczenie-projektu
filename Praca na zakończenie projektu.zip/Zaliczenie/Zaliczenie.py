import pgzrun
import numpy as np


class Dirt(Actor):
    def react(self):
        if np.abs(link.center[1] + link.size[1] / 2 - self.center[1] + self.size[1] / 2) < 15:
            link.vy = 0
            link.bottom = self.top
        elif np.abs(link.center[1] - link.size[1] / 2 - self.center[1] - self.size[1] / 2) < 15:
            link.vy = 0
            link.top = self.bottom
        elif np.abs(link.center[0] + link.size[0] / 2 - self.center[0] + self.size[0] / 2) < 15:
            moveall(6)
        elif np.abs(link.center[0] - link.size[0] / 2 - self.center[0] - self.size[0] / 2) < 15:
            moveall(-6)

    def move(self):
        pass


class Coin(Actor):
    def react(self):
        if link.colliderect(self):
            objs.remove(self)
            link.points = link.points + 1

    def move(self):
        pass

def amimate(self, pos):
    pass


class Dom(Actor):
    def react(self):
        if link.colliderect(self):
            link.win = True

    def move(self):
        pass


def newgame():
    link.pos = (200, HEIGHT - 150)
    link.vy = 0
    link.time = 0
    link.dir = "right"
    link.dead = False
    link.points = 0
    link.win = False

    for i in range(len(objs)):
        objs.remove(objs[0])
    file = open("mapa.dat")
    i = 0

    for line in file:
        for j in range(len(line)):
            if line[j] == "0":
                objs.append(Dirt("dirt.png", (j * 32, 32 * i)))
            elif line[j] == 'S':
                objs.append(Dirt("stone.png", (j * 32, 32 * i)))
            elif line[j] == 'F':
                objs.append(Dirt("sand.png", (j * 32, 32 * i)))
            elif line[j] == 'D':
                objs.append(Dirt("domek.jpg", (j * 32, 32 * i)))
            elif line[j] == 'K':
                objs.append(Coin("banknot.jpg", (j * 32, 32 * i)))
        i = i + 1

        music.play("rockybalboa.mp3")


def draw():
    screen.fill((148, 146, 255))
    for obj in objs:
        obj.draw()
    link.draw()
    screen.draw.text(str(link.points), color="black", midtop=(WIDTH / 8 * 7, 10), fontsize=70, shadow=(0, 0))
    if link.win:
        screen.draw.text("Wygrales!", color="black", midtop=(WIDTH / 2, 10), fontsize=170, shadow=(0, 0))


def moveall(x):
    if x > 0:
        if 0 <= link.x:
            link.x = link.x - x
        elif link.x < 0:
            link.x = 0
    else:
        if 0 <= link.x < WIDTH / 2:
            link.x = link.x - x
        elif link.x > WIDTH / 2:
            link.x = WIDTH / 2
        elif link.x >= WIDTH / 2:
            for obj in objs:
                obj.x = obj.x + x


def move(dt):
    if link.dir == "right":
        link.image = "sonic.png"
    else:
        link.image = "sonic.png"

    uy = link.vy
    link.vy = link.vy + 2000.0 * dt
    link.y = link.y + (uy + link.vy) * 0.5 * dt

    if keyboard.right:
        if link:
            moveall(-2)
        link.dir = "right"
        if link.time < 8:
            link.image = "sonic.png"
        else:
            link.image = "sonic.png"

    if keyboard.left:
        if link:
            moveall(2)
        link.dir = "left"
        if link.time < 8:
            link.image = "sonic.png"
        else:
            link.image = "sonic.png"

    for obj in objs:
        if link.colliderect(obj):
            obj.react()
    if link.vy != 0 and link.dir == "right":
        link.image = "sonic.png"
    elif link.vy != 0 and link.dir == "left":
        link.image = "sonic.png"
    if link.bottom > HEIGHT:
        link.dead = True


def update(dt):
    if not link.win:
        move(dt)
        for obj in objs:
            obj.move()
            if obj.image == "domek.jpg":
                if np.abs(obj.center[0] - link.center[0]) < 20:
                    link.win = True
    if link.dead:

        newgame()


def on_key_down(key):
    if key== keys.SPACE and link.vy == 0:
        link.vy = -800


HEIGHT = 640
WIDTH = 1024
TITLE = "Link"

link = Actor("sonic.png", (200, HEIGHT -120))
link.vy = 0
link.time = 0
link.dir = "right"
link.dead = False
link.points = 0
link.win = False
objs = []
newgame()

pgzrun.go()
